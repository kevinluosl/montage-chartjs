## 0.5.1
-  **Scroller**

   Copied scroller in from matte

## 0.5.0
-  **Overall**

   All widgets are sized with em units, this allows then to be resized easily.
   Flat look was replaced by transparency that can integrate with it;s surroundings.

-  **BigList**

   Based on the flow component, the BigList allows you to recycle elements to achieve an infinite scrolling list.

-  **Button**

   Now works with a simple `<a>` tag.

## 0.4.0

-  **Slider**

   Fix Slider vertical axis
   Improve Slider implementation to only use two elements

## 0.3.2

-  **List**

   Fix List scrolling on touch devices
