utilities for working with htmlparser2's dom
