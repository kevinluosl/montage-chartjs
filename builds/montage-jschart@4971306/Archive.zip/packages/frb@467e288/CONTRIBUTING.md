
-   Make your change.
-   Add a spec.  Run `npm test` to run the specs.  Do not regress.
-   Duplicate the first line of LICENSE.md and change the name to your
    own.
-   Send a pull request on Github.

For changes to `README.md`.

-   Synchronize your code examples with those in `spec/readme-spec.js`
    and run the tests as above.

